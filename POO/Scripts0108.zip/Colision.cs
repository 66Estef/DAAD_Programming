using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Colision : MonoBehaviour
{
    public int score;
    public TextMeshProUGUI scoreText;

    private void Start() {
        scoreText.text = "Score actual: " + score;
    }

    private void Update() {
        if(score >= 5){
            Debug.Log("Ganaste!");
        }
    }
    

private void OnCollisionEnter2D(Collision2D other) {
    

    if (other.gameObject.name=="Plataforma")
    {
        Debug.Log("Ufff!");
    }
    
    if (other.gameObject.tag=="moneda")
    {
        
        score++;
        scoreText.text = "Score actual: " + score;
        Destroy(other.gameObject);
        Debug.Log("Score actual: " + score);
    }
    
}

void OnCollisionStay2D(Collision2D other){
  
}

private void OnCollisionExit2D(Collision2D other) {
    
}

}
